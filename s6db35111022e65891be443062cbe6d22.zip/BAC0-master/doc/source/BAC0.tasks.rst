BAC0.tasks package
==================

Submodules
----------

BAC0.tasks.DoOnce module
------------------------

.. automodule:: BAC0.tasks.DoOnce
   :members:
   :undoc-members:
   :show-inheritance:

BAC0.tasks.Match module
-----------------------

.. automodule:: BAC0.tasks.Match
   :members:
   :undoc-members:
   :show-inheritance:

BAC0.tasks.Poll module
----------------------

.. automodule:: BAC0.tasks.Poll
   :members:
   :undoc-members:
   :show-inheritance:

BAC0.tasks.RecurringTask module
-------------------------------

.. automodule:: BAC0.tasks.RecurringTask
   :members:
   :undoc-members:
   :show-inheritance:

BAC0.tasks.TaskManager module
-----------------------------

.. automodule:: BAC0.tasks.TaskManager
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: BAC0.tasks
   :members:
   :undoc-members:
   :show-inheritance:
