BAC0.core.proprietary\_objects package
======================================

Submodules
----------

BAC0.core.proprietary\_objects.jci module
-----------------------------------------

.. automodule:: BAC0.core.proprietary_objects.jci
   :members:
   :undoc-members:
   :show-inheritance:

BAC0.core.proprietary\_objects.object module
--------------------------------------------

.. automodule:: BAC0.core.proprietary_objects.object
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: BAC0.core.proprietary_objects
   :members:
   :undoc-members:
   :show-inheritance:
