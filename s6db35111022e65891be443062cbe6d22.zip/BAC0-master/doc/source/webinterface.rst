Web Interface
===================================================
Flask App
----------------------------------------

BAC0 when used in "Complete" mode will start a Web app that can be reached with a browser.
The app will present the bokeh server feature for live trending.

More documentation will come in the future as this feature is under development.