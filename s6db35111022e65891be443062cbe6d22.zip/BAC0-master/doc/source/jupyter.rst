Demo in a Jupyter Notebook
==========================
When installed, module can be used to script communication with bacnet device.
Jupyter Notebooks are an excellent way to test it. Here is an example_.

.. _example : https://github.com/ChristianTremblay/BAC0/blob/master/Jupyter/BAC0.ipynb
