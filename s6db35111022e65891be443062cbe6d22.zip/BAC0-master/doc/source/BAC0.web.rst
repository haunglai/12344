BAC0.web package
================

Submodules
----------

BAC0.web.BokehRenderer module
-----------------------------

.. automodule:: BAC0.web.BokehRenderer
   :members:
   :undoc-members:
   :show-inheritance:

BAC0.web.BokehServer module
---------------------------

.. automodule:: BAC0.web.BokehServer
   :members:
   :undoc-members:
   :show-inheritance:

BAC0.web.FlaskServer module
---------------------------

.. automodule:: BAC0.web.FlaskServer
   :members:
   :undoc-members:
   :show-inheritance:

BAC0.web.templates module
-------------------------

.. automodule:: BAC0.web.templates
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: BAC0.web
   :members:
   :undoc-members:
   :show-inheritance:
